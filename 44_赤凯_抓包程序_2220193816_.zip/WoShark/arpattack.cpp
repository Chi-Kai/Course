﻿#include "arpattack.h"


arpattack::arpattack(QWidget* par): QWidget(par)
{

}
